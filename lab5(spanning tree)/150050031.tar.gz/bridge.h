#include <iostream>
#include <vector>
#include <unordered_map>
#include <sstream>
#include <iterator>
#include <fstream>
#include <algorithm>
#include <tuple>
#include <map>

using namespace std;
