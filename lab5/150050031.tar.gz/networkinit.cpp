//#include "bridge.cpp"
//
//extern unordered_map<string, bridge*> all_bridges;
//
//int main()
//{
//    network N;
//    N.input();
//    N.init_stp();
//}