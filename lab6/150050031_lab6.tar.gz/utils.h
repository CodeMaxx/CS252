#include <iostream>

using namespace std;

string iptobin(string ip);
int mask_len(string mask);
