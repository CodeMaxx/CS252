#include <iostream>

using namespace std;

string iptobin(string ip); // Convert a a.b.c.d IP address to its binary form
int mask_len(string mask); // Find the number of 1's in the mask
